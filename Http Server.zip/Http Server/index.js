//declare host and port 
const http = require("http");
const host = "localhost"; //127.0.0.1 (default IP)
const port = 8000; //port number

//request browser to listen on a certain port 
let requestListener = function(req, res) {
    let requestURL = req.url; //the requested URL or web page

    if (requestURL === "/"){ //3 "===" for javascript and "/" is for homepage
        res.end("This is my first server, and I am running it for the first time!!");
    }
    if (requestURL === "/login"){ 
        res.end("login page is requested");   
    }

    res.writeHead(200); //200 means everthing went well
}

//declare server
const server = http.createServer(requestListener);

//tell the server to listen
server.listen(port, host, () =>{
    console.log(`The server is running on http://${host}:${port}`);
});

/*----------------------------------------------------------------------------------

IMPORTANT SYNTAX

const http = require("http");
const host = "localhost";
const port = 8000;

(these are the default code lines for server variables)

let requestListener = function(req, res) ---> this is the default code for requestListener function
{
    let requestURL = reg.URL; ---> this is the default code for requestURL

    if(requestURL === "/<webpage requested>") ----> if statement for various outcomes depending on the requested web page
    {
        res.end("response"); ----> default code line to declare the result
    }

    res.writeHead(200); ---> this is the default code line to declare that it was successful
}

const server = http.createServer(requestListener); ---> this is the default code line to declare the server

server.listen(port, host, () =>
{
    console.log(`The server is running on http://${host}:${port}`);
});

(this is the default code line to declare that the server is running)

-----------------------------------------------------------------------------------*/