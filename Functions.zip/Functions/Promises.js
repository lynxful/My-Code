//Resolve 
//Reject

//3 stage of promise: dormant (no asked yet), fulfilled (resolved successfully), rejected (error occurrred)

const p = new Promise((resolve, reject) => 
    {
        //setTimeout(() => {<function>}, seconds); ----> this sets a timer for x seconds for result to appear.

        setTimeout(() => {
            if(11 < 2) {resolve("words...")} else reject(false)
        }, 1000);
    });

    //x.then(<function>).catch(<function>); ----> error statement.
    
    p.then((fromResolve) => {
        console.Log(fromResolve)
    }).catch((fromReject) => {
        console.log(fromReject)
    });

 //Exercise: change the code so that you use a function that returns a promise

/*-----------------------------------------------------------------------------

i

-------------------------------------------------------------------------------*/

