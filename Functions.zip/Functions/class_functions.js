function calculate(a, b, cb){
    let result = cb(a, b)
    return(result);
}

//add, subtract, division, multiply
function add(a, b){
    return(a+b);
}

//functions can also be written like this:
const Add = ()=> a + b;  
const Subtract = ()=> a - b; 
const Divide = ()=> a / b;
const Multiply = ()=> a * b;

function Output()
{
    console.log("Add: " + calculate(6, 1, add)); 
    console.log("Subtract: " + calculate(5,1, Subtract));
    console.log("Divide: " + calculate(6,2, Divide));
    console.log("Multiply: " + calculate(6,4, Multiply));
}

console.log(output());