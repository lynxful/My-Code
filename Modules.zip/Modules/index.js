//Import multiple functions
const {addition, calculate} = require('./add');

//Import 1 function
//const add = require('./add');

console.log(addition(10, 15));

//Import 1 function
//const calculate = require('./add');

console.log(addition(10, 15));

console.log(calculate(10, 15, "addition"));
console.log(calculate(10, 15, "subtract"));
console.log(calculate(10, 15, "multiply"));
console.log(calculate(10, 15, "divide"));

/*------------------------------------------------------------------------------

IMPORTANT SYNTAX

const <function name> = require('./<file being referenced>); 
(this specifies that you will be referencing a SINGLE function from a different file)

const {<function name>, <function name} = require('./<file being referenced>); 
(this specifies that you will be referencing MULTIPLE functions from a different file)

-------------------------------------------------------------------------------*/