
let addition = (a, b) => {
    return a + b;
}

//specify that it will be exported
//module.exports = addition;

function calculate(a, b, cb){

    switch(cb){
        case "addition":
            return a + b;
            break;
        case "subtract":
            return a - b;
            break;
        case "multiply":
            return a * b;
            break;
        case "divide":
            return a / b;
            break;
        default:
            return "No values given";
            break;
    }
}

//specify that the function will be exported
//module.exports = calculate;

//export multiple functions
module.exports = {addition, calculate}

/*---------------------------------------------------------------------------------------

IMPORTANT SYNTAX

module.exports = <function name>;
(This specifies that you will be exporting a function to be used in a different file)

module.exports = {<function name>, <function name>}
(exports many functions)
----------------------------------------------------------------------------------------*/