let student = [
    {
        name: "Lynnette",
        mark: 83,
    },
    {
        name: "Pieter",
        mark: 30,
    },
    {
        name: "Sarah",
        mark: 75,
    },
];

function AddGrades(students, cb) {
    //setTimeout ---> setTimeout(<function>,<milliseconds>)
    setTimeout(() => 
                    {
                        student.push(students)
                        cb()
                    }, 
    1000)
}

function PrintGrades() {
    student.map(student => {console.log(student)});
}

AddGrades({name: "Oneilwe", mark: 0.20}, PrintGrades);
